import { AbstractControl } from "@angular/forms";

export function ValidateName(control:AbstractControl) {
    console.log(control.value.toLowerCase().match(/[a-z]/g),"dsdsadhaslhd")
    if(!control.value.toLowerCase().match(/[a-z]/g)) {
        return {invalidText:true}
    }
    return null;
}