import { Component } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidateName } from './name.validators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  empGroup:FormGroup = this.fB.group({});
  empData = [
    {
    "userId":"rirani",
    "jobTitleName":"Developer",
    "firstName":"Romin",
    "lastName":"Irani",
    "preferredFullName":"Romin Irani",
    "employeeCode":"E1",
    "region":"CA",
    "phoneNumber":"408-1234567",
    "emailAddress":"romin.k.irani@gmail.com"
    },
    {
    "userId":"nirani",
    "jobTitleName":"Developer",
    "firstName":"Neil",
    "lastName":"Irani",
    "preferredFullName":"Neil Irani",
    "employeeCode":"E2",
    "region":"CA",
    "phoneNumber":"408-1111111",
    "emailAddress":"neilrirani@gmail.com"
    },
    {
    "userId":"thanks",
    "jobTitleName":"Program Directory",
    "firstName":"Tom",
    "lastName":"Hanks",
    "preferredFullName":"Tom Hanks",
    "employeeCode":"E3",
    "region":"CA",
    "phoneNumber":"408-2222222",
    "emailAddress":"tomhanks@gmail.com"
    }
    ]

  constructor(private fB:FormBuilder) {}

  ngOnInit() {
    this.empGroup = this.createEmpFromGroup();
    console.log(this.empGroup,"dsdssds....");
  }

  createEmpFromGroup():FormGroup {
    let formArray = this.fB.array([]);
    this.empData.forEach((res:any)=>{
      let keys = Object.keys(res);
      let grp:any = {}
      console.log(keys);
      keys.forEach((key:any)=>{
        console.log(res[key])
        grp[key] = this.fB.control(res[key],Validators.required);
      });
      console.log(grp);
      formArray.push(this.fB.group(grp));
      console.log(formArray);
    });
    return this.fB.group({'empItems':formArray});
  }

  addItems(item:any,index:number):void {
    let formArray = (this.empGroup.get('empItems') as FormArray);
    let keys = Object.keys(this.empData[0]);
    let grp:any = {}
    keys.forEach((key:any)=>{
      console.log(key)
      grp[key] = this.fB.control('',Validators.required);
    });
    formArray.insert(index+1,this.fB.group(grp));
  }

  get empArray() { return (this.empGroup.get('empItems') as FormArray).controls};

  getError(index:number,ctrl:any) {
    let err = (this.empGroup.get('empItems') as FormArray).controls[index].get(ctrl)?.errors;
    return err ? true:false;
  }
}
